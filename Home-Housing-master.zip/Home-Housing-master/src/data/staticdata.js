import partner1 from "../assets/partners_logo/partner1.png";
import partner2 from "../assets/partners_logo/partner2.png";
import partner3 from "../assets/partners_logo/partner3.png";
import partner4 from "../assets/partners_logo/partner4.png";
import partner5 from "../assets/partners_logo/partner5.png";
import partner6 from "../assets/partners_logo/partner6.png";
import partner7 from "../assets/partners_logo/partner7.png";
import partner8 from "../assets/partners_logo/partner8.png";
import partner9 from "../assets/partners_logo/partner9.png";

const partnersData = [
  {
    name: "partner1",
    image: partner1,
  },
  {
    name: "partner2",
    image: partner2,
  },
  {
    name: "partner3",
    image: partner3,
  },
  {
    name: "partner4",
    image: partner4,
  },
  {
    name: "partner5",
    image: partner5,
  },
  {
    name: "partner6",
    image: partner6,
  },
  {
    name: "partner7",
    image: partner7,
  },
  {
    name: "partner8",
    image: partner8,
  },
  {
    name: "partner9",
    image: partner9,
  },
];

export default partnersData;

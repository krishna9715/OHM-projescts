const backendURL = "https://home-housing-backend.onrender.com";
// const backendURL = "http://127.0.0.1:8000";
export default backendURL;

import React, { useState, useEffect } from "react";
import { Container, Row, Col, Button, Carousel, Form } from "react-bootstrap";
import { motion } from "framer-motion";
import { FaArrowUp, FaPhoneAlt, FaHome, FaUsers, FaBuilding, FaEnvelope } from "react-icons/fa";
import "./hero.css";

const HomePage = () => {
  const [showGoToTop, setShowGoToTop] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const handleScroll = () => {
      setShowGoToTop(window.pageYOffset > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    console.log("Searching for:", searchTerm);
    // Add your search logic here
  };

  return (
    <div>
      <section className="carousel-section my-5 w-100">
        <Container>
          <Row>
            <Col md={8}>
              <Carousel>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=600"
                    alt="First slide"
                  />
                  <Carousel.Caption>
                    <h3>Luxury Villas</h3>
                    <p>Experience premium living with our luxurious homes.</p>
                  </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.pexels.com/photos/259588/pexels-photo-259588.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                    alt="Second slide"
                  />
                  <Carousel.Caption>
                    <h3>Modern Apartments</h3>
                    <p>Find your perfect urban retreat with modern amenities.</p>
                  </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://images.pexels.com/photos/1444424/pexels-photo-1444424.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                    alt="Third slide"
                  />
                  <Carousel.Caption>
                    <h3>Cozy Homes</h3>
                    <p>A place you can call home, with comfort and style.</p>
                  </Carousel.Caption>
                </Carousel.Item>
              </Carousel>
            </Col>

            {/* Right-Side Content */}
            <Col md={4}>
              <div className="right-side-content p-4" style={{ backgroundColor: "#f8f9fa", borderRadius: "8px" }}>
                <h4>Why Choose Us?</h4>
                <p>We offer the best properties in the market, with a focus on premium living and customer satisfaction.</p>
                <ul>
                  <li>Verified Listings</li>
                  <li>Top-rated Properties</li>
                  <li>Experienced Agents</li>
                  <li>24/7 Customer Support</li>
                </ul>
                <Button className="learn-more-btn mt-3">Learn More</Button>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Search Section */}
      <section className="search-section my-5">
        <Container>
          <Form onSubmit={handleSearch} className="d-flex justify-content-center">
            <Form.Control
              type="text"
              placeholder="Search for properties..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="me-2"
              style={{ width: "300px" }}
            />
            <Button type="submit">Search</Button>
          </Form>
        </Container>
      </section>

      <section className="trusted-brands-section">
        <h2 className="text-center mb-4">Brands That Trust Us</h2>
        <marquee behavior="scroll" direction="left" scrollamount="18">
          <img src="https://bsmedia.business-standard.com/_media/bs/img/article/2024-01/27/full/20240127105230.jpg" alt="Brand 1" className="brand-logo" />
          <img src="https://www.casagrand.co.in/wp-content/uploads/2022/03/corporate-video.jpg" alt="Brand 3" className="brand-logo" />
          <img src="https://bsmedia.business-standard.com/_media/bs/img/article/2024-01/27/full/20240127105230.jpg" alt="Brand 1" className="brand-logo" />
          <img src="https://www.casagrand.co.in/wp-content/uploads/2022/03/corporate-video.jpg" alt="Brand 3" className="brand-logo" />
        </marquee>
      </section>

      <section id="recommended-properties" className="recommended-properties my-5">
        <Container>
          <h2 className="text-center mb-4">Recommended Properties</h2>
          <div className="property-carousel-wrapper">
            <div className="property-carousel">
              <div className="property-card">
                <img
                  src=""
                  alt="Property 1"
                  className="img-fluid mb-3"
                />
                <h4>Luxury Villa</h4>
                <p>Experience unmatched luxury and comfort in our premium villas.</p>
                <Button variant="primary">View Details</Button>
              </div>
              <div className="property-card">
                <img
                  src=""
                  alt="Property 2"
                  className="img-fluid mb-3"
                />
                <h4>Modern Apartment</h4>
                <p>Discover modern living spaces equipped with all amenities.</p>
                <Button variant="primary">View Details</Button>
              </div>
              <div className="property-card">
                <img
                  src=""
                  alt="Property 3"
                  className="img-fluid mb-3"
                />
                <h4>Cozy Family Home</h4>
                <p>Find a cozy home for your family, in a friendly neighborhood.</p>
                <Button variant="primary">View Details</Button>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* Customer Reviews Section */}
      <section className="customer-reviews-section my-5">
        <Container>
          <h2 className="text-center mb-4">What Our Customers Say</h2>
          <Row>
            <Col md={4} className="text-center">
              <div className="review-card">
                <p>"Great service and found my dream home!"</p>
                <p>- John Doe</p>
              </div>
            </Col>
            <Col md={4} className="text-center">
              <div className="review-card">
                <p>"The team was very helpful throughout the process."</p>
                <p>- Jane Smith</p>
              </div>
            </Col>
            <Col md={4} className="text-center">
              <div className="review-card">
                <p>"Highly recommend for anyone looking for property!"</p>
                <p>- Sarah Johnson</p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      <section id="properties" className="available-properties my-5">
        <Container>
          <h2 className="text-center mb-4">Our Top Available Properties</h2>
          <Row>
            <Col md={4} className="text-center">
              <FaHome size={50} className="mb-3" color="#4c5288" />
              <h3>Rooms</h3>
              <p>Find luxurious villas designed for premium comfort.</p>
            </Col>
            <Col md={4} className="text-center">
              <FaBuilding size={50} className="mb-3" color="#4c5288" />
              <h3>PG Rooms</h3>
              <p>Urban apartments equipped with the latest amenities.</p>
            </Col>
            <Col md={4} className="text-center">
              <FaUsers size={50} className="mb-3" color="#4c5288" />
              <h3>Family Homes</h3>
              <p>Perfectly sized homes for families, with parks and schools nearby.</p>
            </Col>
          </Row>
        </Container>
      </section>

      <footer className="footer-section text-center py-4">
        <Container>
          <Row>
            <Col md={6}>
              <h4>Register Your Property</h4>
              <p>List your property with us and get found by potential buyers.</p>
              <Button variant="primary">Register Now</Button>
            </Col>
            <Col md={6}>
              <h4>Contact Us</h4>
              <p>
                <FaPhoneAlt /> +1 234 567 890
                <br />
                <FaEnvelope /> info@realestate.com
              </p>
            </Col>
          </Row>
        </Container>
      </footer>

      {showGoToTop && (
        <motion.button
          onClick={scrollToTop}
          className="go-to-top"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <FaArrowUp />
        </motion.button>
      )}
    </div>
  );
};

export default HomePage;

import "./footer.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faBullhorn, faTag, faQuestionCircle, faInfoCircle, faBlog } from '@fortawesome/free-solid-svg-icons';
import { faFacebook, faInstagram, faLinkedin } from '@fortawesome/free-brands-svg-icons';

const Footer = () => {
  return (
    <footer className="footer-bg">
      <div className="container">
        <footer className="py-5">
          <div className="row">
            <div className="col-md-3 mb-3">
              <h5>Main Section</h5>
              <ul className="nav flex-column">
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faHome} /> Home
                  </a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faBullhorn} /> Advertisements
                  </a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faTag} /> Pricing
                  </a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faQuestionCircle} /> FAQs
                  </a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#about" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faInfoCircle} /> About
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-md-3 mb-3">
              <h5>Blogs</h5>
              <ul className="nav flex-column">
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faBlog} /> Read blogs
                  </a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" className="nav-link p-0 text-muted">
                    <FontAwesomeIcon icon={faBlog} /> Top rated blogs
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-md-6 mb-3">
              <form>
                <h5>Subscribe to our newsletter</h5>
                <p>Get property deals every week for free.</p>
                <div className="d-flex flex-column flex-sm-row w-100 gap-2">
                  <label htmlFor="newsletter1" className="visually-hidden">
                    Email address
                  </label>
                  <input
                    id="newsletter1"
                    type="email"
                    className="form-control inputFiledBg"
                    placeholder="Email address"
                    required
                  />
                  <button className="btn btn-dark" type="button">
                    Subscribe
                  </button>
                </div>
              </form>
            </div>
          </div>
          <div className="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top">
            <p>© {new Date().getFullYear()} Company, Inc. All rights reserved.</p>
            <ul className="list-unstyled d-flex">
              <li className="ms-3">
                <a className="link-dark icons-size" href="#">
                  <FontAwesomeIcon icon={faFacebook} />
                </a>
              </li>
              <li className="ms-3">
                <a className="link-dark icons-size" href="#">
                  <FontAwesomeIcon icon={faInstagram} />
                </a>
              </li>
              <li className="ms-3">
                <a className="link-dark icons-size" href="#">
                  <FontAwesomeIcon icon={faLinkedin} />
                </a>
              </li>
            </ul>
          </div>
        </footer>
      </div>
    </footer>
  );
};

export default Footer;

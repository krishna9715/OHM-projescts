import { createContext } from "react";

export const IsLoggedInContext = createContext();
export const UserDetailsContext = createContext();

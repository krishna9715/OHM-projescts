import RegistrationForm from "../../components/RegistrationForm/RegistrationForm";

const RegistrationPage = () => {
  return (
    <>
      <RegistrationForm />
    </>
  );
};

export default RegistrationPage;

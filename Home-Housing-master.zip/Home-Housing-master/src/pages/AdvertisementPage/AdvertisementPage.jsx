import Advertisements from "../../components/Advertisements/Advertisements";

const AdvertisementPage = () => {
  return (
    <>
      <Advertisements />
    </>
  );
};

export default AdvertisementPage;

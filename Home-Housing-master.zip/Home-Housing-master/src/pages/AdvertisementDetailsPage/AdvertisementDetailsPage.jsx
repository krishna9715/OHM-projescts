import AdvertisementDetail from "../../components/AdvertisementDetail/AdvertisementDetail";

const AdvertisementDetailsPage = () => {
  return (
    <>
      <AdvertisementDetail />
    </>
  );
};

export default AdvertisementDetailsPage;

import MyBookings from "../../components/MyBookings/MyBookings";

const MyBookingsPage = () => {
  return (
    <>
      <MyBookings />
    </>
  );
};

export default MyBookingsPage;

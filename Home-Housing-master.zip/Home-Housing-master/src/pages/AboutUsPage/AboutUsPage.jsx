import AboutOurService from "../../components/AboutOurService/AboutOurService";

const AboutUsPage = () => {
  return (
    <>
      <AboutOurService />
    </>
  );
};

export default AboutUsPage;

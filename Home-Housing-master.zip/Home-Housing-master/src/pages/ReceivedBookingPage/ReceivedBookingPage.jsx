import ReceivedBookings from "../../components/ReceivedBookings/ReceivedBookings";

const ReceivedBookingPage = () => {
  return (
    <>
      <ReceivedBookings />
    </>
  );
};

export default ReceivedBookingPage;

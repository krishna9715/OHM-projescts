import AdminRentRequest from "../../components/AdminRentRequest/AdminRentRequest";

const AdminViewRentRequestPage = () => {
  return (
    <>
      <AdminRentRequest />
    </>
  );
};

export default AdminViewRentRequestPage;

import ViewPostedAdvertisement from "../../components/ViewPostedAdvertisment/ViewPostedAdvertisement";

const ViewPostedAdvertisementPage = () => {
  return (
    <>
      <ViewPostedAdvertisement />
    </>
  );
};

export default ViewPostedAdvertisementPage;

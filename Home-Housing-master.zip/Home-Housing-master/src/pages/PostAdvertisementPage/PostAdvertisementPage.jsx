import PostAdvertisementForm from "../../components/PostAdvertiseMentForm/PostAdvertisementForm";

const PostAdvertisementPage = () => {
  return (
    <>
      <PostAdvertisementForm />
    </>
  );
};

export default PostAdvertisementPage;

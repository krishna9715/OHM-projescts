import Home from "../../components/Home/Home";

const Homepage = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default Homepage;
